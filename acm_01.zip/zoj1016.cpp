#include<bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int T;
    cin >> T;
    while(T--) {
        int n;
        cin >> n;
        vector<int> p(n);
        for(int i=0; i<n; i++) {
            cin >> p[i];
        }
        
        stack<int> st;
        int left = 0; // �����ӵ�����������
        vector<int> res;
        
        for(int pi : p) {
            // ������Ҫ��������
            int add = pi - left;
            for(int j=0; j<add; j++) {
                st.push(0);
            }
            left = pi;
            
            // ����������
            int top = st.top();
            st.pop();
            int w = top + 1;
            
            // �ۼӵ����ڵ�
            if(!st.empty()) {
                st.top() += w;
            }
            
            res.push_back(w);
        }
        
        // ������
        for(int i=0; i<res.size(); i++) {
            if(i > 0) cout << " ";
            cout << res[i];
        }
        cout << "\n";
    }
    
    return 0;
}
